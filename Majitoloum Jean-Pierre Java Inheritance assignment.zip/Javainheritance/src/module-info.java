module Javainheritance {
}