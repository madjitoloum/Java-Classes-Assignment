package javaclassesassginment;

public class Q1 {

	public Q1() {
	
		#include <iostream>
		
		using namespace std;
		
		class student{
			
		}
		public:
			
		int roll_no; string name;
		
		void insert( int ron, string n){
			
		roll_no = ron; name = n; }
		
		void display()
		{
		cout<<roll_no<< " "<<name<<endl;}
		
		};
		
		int main(void)
		
		{ cout<<"Roll Name:"<<endl;
		
		student st; student nm;
		
		st.insert(2 ," John" );
		
		st.display();
		
		return 0;
		
	}

}
