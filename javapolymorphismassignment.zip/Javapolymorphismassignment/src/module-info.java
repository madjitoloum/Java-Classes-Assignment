module Javapolymorphismassignment {
}